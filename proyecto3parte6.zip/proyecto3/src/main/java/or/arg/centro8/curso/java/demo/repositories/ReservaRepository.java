package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Reserva;

public class ReservaRepository {
    private Connection conn= Connector.getConnection();

    public void save(Reserva reserva){
        if(reserva==null)return; 
        try (PreparedStatement ps=conn.prepareStatement(
            "Insert into reservas (id_usuario,id_evento,fecha_reservas,cantidad_personas,estado_reservas)values(?,?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
                ps.setInt(1,reserva.getId_usuario());
                ps.setInt(2, reserva.getId_evento());
                ps.setString(3, reserva.getFecha_reservas());
                ps.setInt(4, reserva.getCantidad_personas());
                ps.setString(5, reserva.getEstado_reservas());
                ps.execute();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()) reserva.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void remove(Reserva reserva){
        if(reserva==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from reservas where id=?")){
            ps.setInt(1,reserva.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public List<Reserva> getAll(){
        List<Reserva>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("select *from reservas")){
            while(rs.next()){
                list.add(
                    new Reserva(
                        rs.getInt("id"),
                        rs.getInt("id_usuario"),
                        rs.getInt("id_evento"),
                        rs.getString("fecha_reservas"),
                        rs.getInt("cantidad_personas"),
                        rs.getString("estado_reservas")
                    )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public Reserva getById(int id){
        return getAll()
                       .stream()
                       .filter(r->r.getId()==id)
                       .findAny()
                       .orElse(new Reserva());
    }

    public List<Reserva> getLikeEstadoReservas(String estado_reservas){
        return getAll()
                      .stream()
                      .filter(r->r.getEstado_reservas().toLowerCase().contains(estado_reservas))
                      .toList();

    }

    public List<Reserva>getByIdUsuario(int id_usuario){
        return getAll()
                       .stream()
                       .filter(r->r.getId_usuario()== id_usuario)
                       .toList();
                       
    }
}
