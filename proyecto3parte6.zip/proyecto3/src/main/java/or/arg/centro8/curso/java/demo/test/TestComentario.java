package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Comentario;

public class TestComentario {
    public static void main(String[] args) {
        System.out.println("--Comentarios--");
        Comentario comentario1=new Comentario(2, 02, 01, "Que bueno que estuvo la fiesta!","10/02/2025");
        System.out.println(comentario1);


    }


}
