package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Usuario;

public class UsuarioRepository {

    private Connection conn=Connector.getConnection();

    public void save(Usuario usuario){
        if(usuario==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into usuarios(nombre, apellido,edad,email,telefono,tipo_usuario,ciudad,zona)values(?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
                ps.setString(1,usuario.getNombre());
                ps.setString(2, usuario.getApellido());
                ps.setString(4,usuario.getEmail());
                ps.setString(5,usuario.getTelefono());
                ps.setString(5,usuario.getTipo_usuario());
                ps.setString(6,usuario.getCiudad());
                ps.setString(7,usuario.getZona());
                ps.execute();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()) usuario.setId(rs.getInt(1));

            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Usuario usuario){
        if(usuario==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from usuarios where id=?")){
            ps.setInt(1,usuario.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Usuario getById(int id){
        return getAll()
                       .stream()
                       .filter(u->u.getId()==id)
                       .findAny()
                       .orElse(new Usuario());
    }
    public List<Usuario> getAll(){
        List<Usuario>list=new ArrayList<>();
        try  (ResultSet rs=conn.createStatement().executeQuery("select *from usuarios")) {
            while (rs.next()) {
                list.add(
                    new Usuario(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("email"),
                        rs.getString("telefono"),
                        rs.getString("tipo_usuario"),
                        rs.getString("ciudad"),
                        rs.getString("zona")
                    )

                    
                );
                
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Usuario>getLikeApellido(String apellido){
        return getAll()
                       .stream()
                       .filter(u->u.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                       .toList();
                    

    }
}
