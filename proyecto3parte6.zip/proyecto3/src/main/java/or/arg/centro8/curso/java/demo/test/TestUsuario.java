package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Usuario;

public class TestUsuario {
    public static void main(String[] args) {
        System.out.println("---Usuario1---");
        Usuario usuario1= new Usuario(1, "Carla", "Perez", "CarlaP@gmail.com", "1134567891","cliente","Buenos Aires","Caseros");
        System.out.println(usuario1);

    }
}
