package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Reserva;
import or.arg.centro8.curso.java.demo.repositories.ReservaRepository;

public class TestReservaRepository {
    
    public static void main(String[] args) {
        ReservaRepository rr=new ReservaRepository();

        Reserva reserva=new Reserva(1, 01, 01, "10/02/2025", 5, "confirmado");

        rr.save(reserva);
        System.out.println(reserva);

        rr.remove(rr.getById(2));

        System.out.println("-----------------------------------------");
        rr.getAll().forEach(System.out::println);

        System.out.println("-------------------------------------------------------");
        rr.getLikeEstadoReservas("confir").forEach(System.out::println);

        System.out.println("-------------------------------------------------------");

        rr.getByIdUsuario(3).forEach(System.out::println);


    }
}
