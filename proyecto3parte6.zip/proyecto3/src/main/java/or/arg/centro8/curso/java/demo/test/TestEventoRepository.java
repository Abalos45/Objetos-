package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Evento;
import or.arg.centro8.curso.java.demo.repositories.EventoRepository;

public class TestEventoRepository {
    public static void main(String[] args) {
        EventoRepository er=new EventoRepository();
        Evento evento=new Evento(0, 02, "Halloween", "Disfraz ganador", "01/11/2025","caba","Acoyte 3035");
        er.save(evento);
        System.out.println(evento);

       er.remove(er.getById(2));


        System.out.println("------------------------------------------");
        er.getAll().forEach(System.out::println);

        System.out.println("------------------------------------------");

        er.getLikeCiudad("Cartagena").forEach(System.out::println);

        System.out.println("------------------------------------------");
        er.getLikeNombreEvento("Carnaval del Caribe").forEach(System.out::println);

      

    }
}
