-- 1. Obtener todos los usuarios y los eventos que han reservado
SELECT u.nombre, u.apellido, e.nombre_evento
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario
JOIN eventos e ON e.id = r.id_evento;

-- 2. Contar cuántas reservas hay por evento
SELECT e.nombre_evento, COUNT(r.id) AS total_reservas
FROM eventos e
LEFT JOIN reservas r ON e.id = r.id_evento
GROUP BY e.id;

-- 3. Listar los eventos que aún no tienen reservas
SELECT e.nombre_evento
FROM eventos e
LEFT JOIN reservas r ON e.id = r.id_evento
WHERE r.id IS NULL;

-- 4. Obtener los nombres de los usuarios y la fecha del evento reservado
SELECT u.nombre, u.apellido, e.nombre_evento, e.fecha AS fecha_evento
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario
JOIN eventos e ON e.id = r.id_evento;

-- 5. Listar todos los eventos y el tipo de usuario que los reservó
SELECT e.nombre_evento, u.tipo_usuario
FROM eventos e
JOIN reservas r ON e.id = r.id_evento
JOIN usuarios u ON r.id_usuario = u.id;

-- 6. Obtener la lista de reservas ordenadas por estado
SELECT u.nombre, u.apellido, e.nombre_evento, r.estado_reservas
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario
JOIN eventos e ON r.id_evento = e.id
ORDER BY r.estado_reservas;

-- 7. Buscar los usuarios que tienen reservas confirmadas
SELECT u.nombre, u.apellido, e.nombre_evento
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario
JOIN eventos e ON e.id = r.id_evento
WHERE r.estado_reservas = 'Confirmada';

-- 8. Listar todos los locales y los eventos que han creado
SELECT u.nombre AS nombre_local, u.apellido, e.nombre_evento, e.ciudad
FROM usuarios u
JOIN eventos e ON e.id_local = u.id
WHERE u.tipo_usuario = 'local';

-- 9. Contar reservas por ciudad de evento
SELECT e.ciudad, COUNT(r.id) AS total_reservas
FROM eventos e
LEFT JOIN reservas r ON e.id = r.id_evento
GROUP BY e.ciudad;

-- 10. Obtener detalles de los eventos y su organizador (local), ordenados por fecha
SELECT e.nombre_evento, e.fecha, CONCAT(u.nombre, ' ', u.apellido) AS organizador
FROM eventos e
JOIN usuarios u ON e.id_local = u.id
ORDER BY e.fecha;

-- 11. Listar los usuarios y los eventos que tienen como favoritos
SELECT u.nombre, u.apellido, e.nombre_evento
FROM favoritos f
JOIN usuarios u ON f.id_usuario = u.id
JOIN eventos e ON e.id = f.id_eventos;

-- 12. Obtener la lista de eventos y la cantidad de veces que fueron marcados como favoritos
SELECT e.nombre_evento, COUNT(f.id) AS total_favoritos
FROM eventos e
LEFT JOIN favoritos f ON e.id = f.id_eventos
GROUP BY e.id
ORDER BY total_favoritos DESC;

-- 13. Buscar todos los usuarios que comentaron un evento específico
SELECT u.nombre, u.apellido, c.texto_comentario
FROM comentarios c
JOIN usuarios u ON c.id_usuario = u.id
JOIN eventos e ON c.id_evento = e.id
WHERE e.nombre_evento = 'Concierto Rock';

-- 14. Obtener todos los eventos y la lista de usuarios que comentaron
SELECT e.nombre_evento, GROUP_CONCAT(CONCAT(u.nombre, ' ', u.apellido) SEPARATOR ', ') AS usuarios_comentaron
FROM eventos e
LEFT JOIN comentarios c ON e.id = c.id_evento
LEFT JOIN usuarios u ON c.id_usuario = u.id
GROUP BY e.id;

-- 15. Listar todos los usuarios que tienen al menos una reserva
SELECT DISTINCT u.nombre, u.apellido, u.tipo_usuario
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario;

-- 16. Obtener el nombre del evento y el número de comentarios por evento
SELECT e.nombre_evento, COUNT(c.id) AS total_comentarios
FROM eventos e
LEFT JOIN comentarios c ON e.id = c.id_evento
GROUP BY e.id;

-- 17. Obtener los eventos que tienen más de 3 reservas
SELECT e.nombre_evento, COUNT(r.id) AS total_reservas
FROM eventos e
JOIN reservas r ON e.id = r.id_evento
GROUP BY e.id
HAVING total_reservas > 3;

-- 18. Listar los usuarios y los eventos que organizaron o reservaron
SELECT u.nombre, u.apellido, e.nombre_evento, 
       CASE 
           WHEN u.tipo_usuario = 'local' THEN 'Organizador'
           ELSE 'Asistente'
       END AS rol
FROM usuarios u
JOIN reservas r ON u.id = r.id_usuario
JOIN eventos e ON e.id = r.id_evento;

-- 19. Obtener los eventos con reservas pendientes
SELECT e.nombre_evento, e.ciudad, COUNT(r.id) AS total_pendientes
FROM eventos e
JOIN reservas r ON e.id = r.id_evento
WHERE r.estado_reservas = 'Pendiente'
GROUP BY e.id;

-- 20. Listar todos los usuarios con sus reservas, comentarios y favoritos
SELECT 
    CONCAT(u.nombre, ' ', u.apellido) AS usuario,
    e.nombre_evento,
    r.estado_reservas,
    c.texto_comentario,
    f.fecha AS fecha_favorito
FROM usuarios u
LEFT JOIN reservas r ON u.id = r.id_usuario
LEFT JOIN eventos e ON e.id = r.id_evento
LEFT JOIN comentarios c ON c.id_usuario = u.id AND c.id_evento = e.id
LEFT JOIN favoritos f ON f.id_usuario = u.id AND f.id_eventos = e.id
ORDER BY u.nombre;
