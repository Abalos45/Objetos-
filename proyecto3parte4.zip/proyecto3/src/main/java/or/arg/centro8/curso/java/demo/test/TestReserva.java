package or.arg.centro8.curso.java.demo.test;


import or.arg.centro8.curso.java.demo.entities.Reservas;

public class TestReserva {
    public static void main(String[] args) {
        System.out.println("--Reserva1--");
        Reservas reserva1=new Reservas(1, 01, 01,"10/02/2025",5,"Confirmada");
        System.out.println(reserva1);

        
        
    
    }
}
