package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Eventos;

public class TestEventos {
    public static void main(String[] args) {
        System.out.println("--Evento1--");
        Eventos evento1=new Eventos(1, 001, "Fiesta Halloween", "Disfraces","10/02/2025", "caba", "Villa Crespo");
        System.out.println(evento1);
    }
}
