package or.arg.centro8.curso.java.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Usuarios {
    private int id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private String tipo_usuario;
    private String ciudad;
    private String zona;
}
