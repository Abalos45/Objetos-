package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Comentarios;

public class TestComentarios {
    public static void main(String[] args) {
        System.out.println("--Comentarios--");
        Comentarios comentario1=new Comentarios(2, 02, 01, "Que bueno que estuvo la fiesta!","10/02/2025");
        System.out.println(comentario1);
    }


}
