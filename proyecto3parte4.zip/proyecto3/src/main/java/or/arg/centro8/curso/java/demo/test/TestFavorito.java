package or.arg.centro8.curso.java.demo.test;


import or.arg.centro8.curso.java.demo.entities.Favoritos;

public class TestFavorito {
    public static void main(String[] args) {
        System.out.println("--Favoritos1--");
        Favoritos favorito=new Favoritos(1, 1, 01,"10/02/2025");
        System.out.println(favorito);
    }
}
