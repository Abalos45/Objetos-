package or.arg.centro8.curso.java.demo.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reservas {
    private int id;
    private int id_usuarios;
    private int id_eventos;
    private String fecha_reservas;
    private int cantidad_personas;
    private String estado_reservas;
    
}
