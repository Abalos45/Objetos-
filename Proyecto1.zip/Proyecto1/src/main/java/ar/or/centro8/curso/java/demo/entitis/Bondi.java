package ar.or.centro8.curso.java.demo.entitis;

public  final class Bondi extends Vehiculo {
    public Bondi(String color, String marca, String modelo, int precio){
        super(color, marca, modelo, precio);
        agregarRadio(getRadio());
    }
    
}
