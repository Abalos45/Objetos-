package ar.or.centro8.curso.java.demo.entitis;

public class AutoNuevo extends Vehiculo{

    public AutoNuevo(String color, String marca,String modelo, int precio, Radio radio){
        super(color, marca,modelo, precio);
        agregarRadio(radio);

    }

    @Override
    public String toString() {
        return "AutoNuevo: "+super.toString();
    }
}
