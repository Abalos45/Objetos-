package ar.or.centro8.curso.java.demo.test;

import ar.or.centro8.curso.java.demo.entitis.AutoClasico;
import ar.or.centro8.curso.java.demo.entitis.AutoNuevo;
import ar.or.centro8.curso.java.demo.entitis.Bondi;
import ar.or.centro8.curso.java.demo.entitis.Radio;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("-- Test Vehiculo--");

        System.out.println("--Auto Nuevo sin radio--");
        AutoNuevo autoN1= new AutoNuevo("Rojo", "Ford", "Bronco Sport", 5900000, null);
        System.out.println(autoN1);

        System.out.println("----------------------------------------------------");

        System.out.println("--Auto Nuevo con radio--");
        Radio radioSony=new Radio("Sony", 50);
        AutoNuevo autoN2ConRadio=new AutoNuevo("Citroen ", "blanco", "back", 6000000,radioSony);
        autoN2ConRadio.agregarRadio(radioSony);
        System.out.println(autoN2ConRadio);

        System.out.println("----------------------------------------------------");

        System.out.println("--Auto Clasico--");
        AutoClasico autoC1= new AutoClasico("Azul", "Fiat", "Cronos", 3000000);
        System.out.println(autoC1);

         System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi1=new Bondi("Amarillo", "Marcopolo", "bus", 8000000);
         Radio r=new Radio("Car Stero", 60);
         bondi1.agregarRadio(r);
         System.out.println(bondi1);


          System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi2=new Bondi("Amarrillo", "Marcopolo", "c", 1000000);
         System.out.println(bondi2);


        



    }
}
