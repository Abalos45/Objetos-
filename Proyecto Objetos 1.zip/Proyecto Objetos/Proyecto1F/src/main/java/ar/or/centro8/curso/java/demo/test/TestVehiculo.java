package ar.or.centro8.curso.java.demo.test;

import ar.or.centro8.curso.java.demo.entitis.AutoClasico;
import ar.or.centro8.curso.java.demo.entitis.AutoNuevo;
import ar.or.centro8.curso.java.demo.entitis.Bondi;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("-- Test Vehiculo--");

        System.out.println("--Auto Nuevo --");
        AutoNuevo autoNuevo=new AutoNuevo("Citroen ", "blanco", "back", 6000000,"Sony",60);
        System.out.println(autoNuevo);

        System.out.println("----------------------------------------------------");

         System.out.println("--Auto Nuevo (cambiamos la radio) --");
         autoNuevo.agregarRadio("Pionner",60);
         System.out.println(autoNuevo);

        System.out.println("----------------------------------------------------");

        System.out.println("--Auto Clasico--");
        AutoClasico autoC1= new AutoClasico("Azul", "Fiat", "Cronos", 3000000);
        System.out.println(autoC1);

         System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi1=new Bondi("Amarillo", "Marcopolo", "bus", 8000000);
         bondi1.agregarRadio("Car Stero",80);
         System.out.println(bondi1);


          System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi2=new Bondi("Amarrillo", "Marcopolo", "c", 1000000);
         System.out.println(bondi2);


    }
}
