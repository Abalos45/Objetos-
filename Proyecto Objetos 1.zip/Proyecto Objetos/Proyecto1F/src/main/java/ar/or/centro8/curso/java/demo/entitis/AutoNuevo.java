package ar.or.centro8.curso.java.demo.entitis;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String color, String marca, String modelo, int precio, String marcaRadio, int potencia) {
        super(color, marca, modelo, precio);
        super.agregarRadio(marcaRadio, potencia);

    }
}
