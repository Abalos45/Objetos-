package ar.or.centro8.curso.java.demo.entitis;

public abstract class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    private int precio;
    private Radio radio;

    @Override
    public String toString() {
        String infoRadio = (radio != null)
                ? "Marca Radio: " + radio.getMarca() + ", Potencia Radio: " + radio.getPotencia()
                : "Sin radio";
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", " + infoRadio + "]";
    }

    public Vehiculo(String color, String marca, String modelo, int precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.radio = null;
    }

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public Radio getRadio() {
        return radio;
    }

    public void agregarRadio(String marca, int potencia) {
        this.radio= new Radio(marca, potencia);

    }

}
