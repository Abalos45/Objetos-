package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Favorito;

public class FavoritoRepository {

    private Connection conn = Connector.getConnection();

    public void save(Favorito favorito) {
        if (favorito == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into favoritos (id,id_usuario,id_eventos,fecha)values(?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, favorito.getId());
            ps.setInt(2, favorito.getId_usuario());
            ps.setInt(3, favorito.getId_eventos());
            ps.setString(4, favorito.getFecha());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                favorito.setId(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Favorito favorito) {
        if (favorito == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from favoritos where id=?")) {
            ps.setInt(1, favorito.getId());
            ps.execute();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Favorito getById(int id) {
        return getAll()
                .stream()
                .filter(f -> f.getId() == id)
                .findAny()
                .orElse(new Favorito());

    }
    public List<Favorito>getAll() {
        List<Favorito> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select *from favoritos")) {
            while (rs.next()) {
                list.add(
                        new Favorito(
                                rs.getInt("id"),
                                rs.getInt("id_usuario"),
                                rs.getInt("id_eventos"),
                                rs.getString("fecha")));

            }

        } catch (Exception e) {
            System.out.println(e);
        }
                return list;
    }

    public List<Favorito> getByIdUsuario(int id_usuario) {
        return getAll()
                        .stream()
                        .filter(f->f.getId_usuario()==id_usuario)
                        .toList();

    }

    public List<Favorito> getByIdEventos(int id_eventos) {
        return getAll()
                       .stream()
                       .filter(f->f.getId_eventos()==id_eventos)
                       .toList();
    }
    public List<Favorito>getLikeFecha(String fecha){
        return getAll()
                       .stream()
                       .filter(f->f.getFecha().contains(fecha))
                       .toList();

    }
}

