package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Evento;
import or.arg.centro8.curso.java.demo.repositories.EventoRepository;

public class TestEventoRepository {
    public static void main(String[] args) {
        EventoRepository er = new EventoRepository();
        Evento evento = new Evento(22, 02, "Halloween", "Disfraz ganador", "2025-11-01", "caba", "Acoyte 3035");
        er.save(evento);
        System.out.println(evento);

        er.remove(er.getById(22));

        System.out.println("------------------------------------------");
        er.getAll().forEach(System.out::println);

        System.out.println("------------------------------------------");

        er.getLikeCiudad("Cartagena").forEach(System.out::println);

        System.out.println("------------------------------------------");
        er.getLikeNombreEvento("fo").forEach(System.out::println);

    }
}
