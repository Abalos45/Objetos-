package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Evento;

public class TestEvento {
    public static void main(String[] args) {
        System.out.println("--Evento1--");
        Evento evento1=new Evento(22, 001, "Fiesta Halloween", "Disfraces","2025-10-02", "caba", "Villa Crespo");
        System.out.println(evento1);
    }
}
