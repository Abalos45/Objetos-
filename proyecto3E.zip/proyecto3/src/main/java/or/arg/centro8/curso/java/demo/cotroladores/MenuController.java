package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.web.bind.annotation.GetMapping;

public class MenuController {
    
    @GetMapping("menu")
    public String getMenu(){
        return "menu";
    }
}
