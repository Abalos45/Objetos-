package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


import or.arg.centro8.curso.java.demo.repositories.EventoRepository;

public class EventoController {
   private  EventoRepository er=new EventoRepository();
   private String mensaje="Bienvenido aqui podras visualizar todos los eventos";

   @GetMapping("/evento")
   public String getEvento(Model model,@RequestParam(name="buscar",defaultValue = "")String buscar){
           model.addAttribute("mensaje",mensaje);
           model.addAttribute("eventos",er.getAll());
           model.addAttribute("eventos",er.getLikeNombreEvento(buscar));
           model.addAttribute("eventos",er.getLikeCiudad(buscar));
           return "evento";

   }
}
