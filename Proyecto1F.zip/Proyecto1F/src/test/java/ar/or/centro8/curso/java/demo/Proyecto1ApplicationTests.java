package ar.or.centro8.curso.java.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
