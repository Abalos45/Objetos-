package ar.or.centro8.curso.java.demo.entitis;

public class Radio {

    private String marca;
    private int potencia;
    private boolean enUso = false;

    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }

    public Radio(String marca, int potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

    public String getMarca() {
        return marca;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public boolean estaEnUso() {
        return enUso;
    }

    public void marcarEnUso() {
        this.enUso = true;
    }

    public void liberar() {
        this.enUso = false;
    }

}
