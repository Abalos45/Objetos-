package ar.or.centro8.curso.java.demo.test;

import ar.or.centro8.curso.java.demo.entitis.AutoClasico;
import ar.or.centro8.curso.java.demo.entitis.AutoNuevo;
import ar.or.centro8.curso.java.demo.entitis.Bondi;
import ar.or.centro8.curso.java.demo.entitis.Radio;

public class TestVehiculo {
    public static void main(String[] args) {
        System.out.println("-- Test Vehiculo--");

        System.out.println("--Auto Nuevo --");
        Radio radioSony=new Radio("Sony", 50);
        AutoNuevo autoNuevo=new AutoNuevo("Citroen ", "blanco", "back", 6000000,radioSony);
        System.out.println(autoNuevo);

        System.out.println("----------------------------------------------------");

         System.out.println("--Auto Nuevo (cambiamos la radio) --");
         Radio radio2= new Radio("Pionner", 60);
         autoNuevo.agregarRadio(radio2);
         System.out.println(autoNuevo);

        System.out.println("----------------------------------------------------");

        System.out.println("--Auto Clasico--");
        AutoClasico autoC1= new AutoClasico("Azul", "Fiat", "Cronos", 3000000);
        System.out.println(autoC1);

         System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi1=new Bondi("Amarillo", "Marcopolo", "bus", 8000000);
         Radio r=new Radio("Car Stero", 60);
         bondi1.agregarRadio(r);
         System.out.println(bondi1);


          System.out.println("----------------------------------------------------");

         System.out.println("--Bondi--");
         Bondi bondi2=new Bondi("Amarrillo", "Marcopolo", "c", 1000000);
         System.out.println(bondi2);


        



    }
}
