package ar.or.centro8.curso.java.demo.entitis;

public class AutoClasico extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo, int precio) {
        super(color, marca, modelo, precio);

    }

    @Override
    public String toString() {
        return "AutoClasico:" + super.toString();
    }

}
