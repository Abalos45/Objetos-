package or.arg.centro8.curso.java.demo.test;


import or.arg.centro8.curso.java.demo.entities.Reserva;

public class TestReserva {
    public static void main(String[] args) {
        System.out.println("--Reserva1--");
        Reserva reserva1=new Reserva(21, 01, 01,"10/02/2025",5,"Confirmada");
        System.out.println(reserva1);

        
        
    
    }
}
