package or.arg.centro8.curso.java.demo.cotroladores;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.utils.DataConfig;



@Controller
public class ConfiguracionController {

    @GetMapping("configuracion")
    public String getConfiguracion(Model model){
        model.addAttribute("so",DataConfig.getSo());
        model.addAttribute("java", DataConfig.getJava());
        model.addAttribute("username",DataConfig.getUserName());
        model.addAttribute("db",Connector.getUrl());
        return "configuracion";
    }
}
