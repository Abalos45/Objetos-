package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import or.arg.centro8.curso.java.demo.entities.Usuario;
import or.arg.centro8.curso.java.demo.repositories.UsuarioRepository;

@Controller
public class UsuarioController {
    private UsuarioRepository ur=new UsuarioRepository();
    private String mensaje="Ingrese un nuevo Usuario";

    @GetMapping("/usuario")
    public String getUsuario(
        Model model,@RequestParam(name="buscar",defaultValue = "")String buscar)
        { 
         Usuario usuario= new Usuario();
         model.addAttribute("mensaje",mensaje);
         model.addAttribute("usuario",usuario);
          model.addAttribute("busquedaPlaceholder","Buscar por Apellido");
           model.addAttribute("busquedaAction","usuario");
         model.addAttribute("usuarios",ur.getLikeApellido(buscar));
    
    return "usuario";
    }
    @PostMapping("/guardarUsuario")
    public String guardarUsuario(@ModelAttribute Usuario usuario){
        ur.save(usuario);
        if(usuario.getId()>0)    mensaje="Se Guardo el usuario id"+ usuario.getId();
        else                      mensaje="No se guardo el usuario!";
        return "redirect:/usuario";
    }

}
