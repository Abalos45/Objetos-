package or.arg.centro8.curso.java.demo.utils;

public class DataConfig {
    public static String getSo(){
        return System.getProperty("os.name")+" "+ 
               System.getProperty("os.version")+" "+
               System.getProperty("os.arch");
               
    }
    public static String getJava(){
        return System.getProperty("java.vm.version")+" "+
                System.getProperty("java.vm.name")+" "+
                System.getProperty("java.version.date");
    }
    public static String getUserName(){
        return System.getProperty("user.name");
    }
    
}
