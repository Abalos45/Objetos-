drop database if exists eventos;
create database eventos;
use eventos;
create table usuarios(
id int not null  auto_increment primary key,
nombre varchar (25) not null,
apellido varchar(25) not null,
email varchar(30) not null unique,
telefono varchar(11),
tipo_usuario varchar(10) not null,
ciudad varchar(100),
zona varchar(100)
);
create table eventos (
id int  not null auto_increment primary key,
id_local int not null,
nombre_evento varchar(40),
descripcion varchar (100),
fecha datetime,
ciudad varchar(100),
ubicacion varchar(100),
foreign key (id_local) references usuarios(id)
);

create table reservas(
id int not null auto_increment primary key,
id_usuario int ,
id_evento int ,
fecha_reservas datetime not null,
cantidad_personas int default 1,
estado_reservas varchar(25),
foreign key (id_usuario) references usuarios ( id),
foreign key(id_evento) references  eventos( id)
);

create table comentarios(
id int AUTO_INCREMENT primary key,
id_usuario int,
id_evento int,
texto_comentario varchar (250),
fecha datetime,
foreign key (id_usuario) references usuarios(id),
foreign key (id_evento) references eventos(id)
);

create table favoritos(
id int AUTO_INCREMENT primary key,
id_usuario int,
id_eventos int,
fecha datetime,
foreign key (id_usuario) references usuarios(id),
foreign key (id_eventos) references eventos(id)
);