package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import or.arg.centro8.curso.java.demo.entities.Favorito;
import or.arg.centro8.curso.java.demo.repositories.FavoritoRepository;


@Controller

public class FavoritoController {
    private FavoritoRepository fr=new FavoritoRepository();
    private String mensaje="Visualiza y guarda tus favoritos";

    @GetMapping("/favorito")
    public String getFavorito(Model model,@RequestParam(name="buscar",defaultValue = "")String buscar){
        Favorito favorito=new Favorito();
        model.addAttribute("mensaje",mensaje);
        model.addAttribute("favorito", favorito);
        model.addAttribute("favoritos",fr.getLikeFecha(buscar));
        return "favorito";
    }
    @PostMapping("guardarFavorito")
    public String guardarFavorito(@ModelAttribute  Favorito favorito){
       fr.save(favorito);
        if(favorito.getId()>0)  mensaje="El evento asido guardado en favoritos"+ favorito.getId();
        else                    mensaje="No se guardo el evento!";
        return "redirect:/favorito";
    }
}
