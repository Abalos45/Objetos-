package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Comentario;

public class ComentarioRepository {
    private Connection conn=Connector.getConnection();
    public void save(Comentario comentario){
        if(comentario==null)return;
        try(PreparedStatement ps=conn.prepareStatement(
            "insert into comentarios(id,id_usuario,id_evento,texto_comentario,fecha)values(?,?,?,?,?)",
                   PreparedStatement.RETURN_GENERATED_KEYS)){  
                    ps.setInt(1,comentario.getId());
                    ps.setInt(2, comentario.getId_usuario());
                    ps.setInt(3, comentario.getId_evento());
                    ps.setString(4, comentario.getTexto_comentario());
                    ps.setString(5, comentario.getFecha());
                    ps.execute(); 
                    ResultSet rs=ps.getGeneratedKeys();
                    if(rs.next())comentario.setId(rs.getInt(1));    
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void remove(Comentario comentario){
        if(comentario==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from comentarios where id=?")) {
            ps.setInt(1, comentario.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public Comentario getById(int id){
        return getAll()
                       .stream()
                       .filter(c->c.getId()==id)
                       .findAny()
                       .orElse(new Comentario());
    }
    public List<Comentario> getAll(){
        List<Comentario>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from comentarios")){
            while (rs.next()) {
                list.add(
                    new Comentario(
                        rs.getInt("id"),
                        rs.getInt("id_usuario"),
                        rs.getInt("id_evento"),
                        rs.getString("texto_comentario"),
                        rs.getString("fecha")
                )
             );
                        
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
          return list;
    }
    public List<Comentario>getByIdUsuario(int id_usuario){
        return getAll()
                       .stream()
                       .filter(c->c.getId_usuario()==id_usuario)
                       .toList();
                      

        
    }

    public List<Comentario>getByIdEvento(int id_evento){
        return getAll()
                       .stream()
                       .filter(c->c.getId_evento()==id_evento)
                       .toList();
    }

    public List<Comentario>getLikeFecha(String fecha ){
        return getAll()
                       .stream()
                       .filter(c->c.getFecha().contains(fecha))
                       .toList();
    }

    public List<Comentario>getLikeTextoComentario(String texto_comentario){
        return getAll()
                       .stream()
                       .filter(c->c.getTexto_comentario().toLowerCase().contains(texto_comentario.toLowerCase()))
                       .toList();

    }


    
}
