package or.arg.centro8.curso.java.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comentario {
    private int id;
    private int id_usuario;
    private int id_evento;
    private String texto_comentario;
    private String fecha;
}
