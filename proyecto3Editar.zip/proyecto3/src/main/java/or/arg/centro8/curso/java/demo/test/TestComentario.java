package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Comentario;

public class TestComentario {
    public static void main(String[] args) {
        System.out.println("--Comentarios--");
        Comentario comentario1=new Comentario(21, 02, 01, "Que bueno que estuvo la fiesta!","2025-11-02");
        System.out.println(comentario1);


    }


}
