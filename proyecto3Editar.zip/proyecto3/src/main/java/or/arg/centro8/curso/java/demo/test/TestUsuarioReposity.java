package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Usuario;
import or.arg.centro8.curso.java.demo.repositories.UsuarioRepository;

public class TestUsuarioReposity {
    public static void main(String[] args) {
        UsuarioRepository ur=new UsuarioRepository();

        Usuario usuario=new Usuario(0, "jasmin", "Peralta", "jasmin_P@gmail.com", "1134567281","cliente","caba","Villa Crespo");
        ur.save(usuario);
       System.out.println(usuario);

        ur.remove(ur.getById(21));

        
        System.out.println("---------------------");
        ur.getAll().forEach(System.out::println);

        System.out.println("------------------------------------------");
        ur.getLikeApellido("tro").forEach(System.out::println);
        
    }
}
