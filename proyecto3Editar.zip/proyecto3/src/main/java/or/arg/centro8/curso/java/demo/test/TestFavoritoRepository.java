package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Favorito;
import or.arg.centro8.curso.java.demo.repositories.FavoritoRepository;

public class TestFavoritoRepository {
    public static void main(String[] args) {
        FavoritoRepository fr = new FavoritoRepository();

        Favorito favorito = new Favorito(22, 02, 10, "2025-10-22");
        fr.save(favorito);
        System.out.println(favorito);

        fr.remove(fr.getById(22));

        System.out.println("-----------------------------------------------------------------------------------");

        fr.getAll().forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");
        fr.getByIdEventos(4).forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");
        fr.getByIdUsuario(5).forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");

        fr.getLikeFecha("2025-10-20").forEach(System.out::println);
    }
}
