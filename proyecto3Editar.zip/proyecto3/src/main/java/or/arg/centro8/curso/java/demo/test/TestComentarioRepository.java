package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Comentario;
import or.arg.centro8.curso.java.demo.repositories.ComentarioRepository;

public class TestComentarioRepository {
    public static void main(String[] args) {
        ComentarioRepository cr = new ComentarioRepository();

        Comentario comentario = new Comentario(22, 3, 4, "Estuvo Genial", "2025-10-11");
        cr.save(comentario);
        System.out.println(comentario);

        cr.remove(cr.getById(22));

        System.out.println("--------------------------------------------------------------------------");

        cr.getAll().forEach(System.out::println);

        System.out.println("--------------------------------------------------------------------------");

        cr.getByIdEvento(4).forEach(System.out::println);

        System.out.println("--------------------------------------------------------------------------");
        cr.getByIdUsuario(2).forEach(System.out::println);

        System.out.println("--------------------------------------------------------------------------");
        cr.getLikeFecha("2025-11-16").forEach(System.out::println);

        System.out.println("--------------------------------------------------------------------------");
        cr.getLikeTextoComentario("no").forEach(System.out::println);

    }
}
