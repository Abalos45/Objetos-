package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import or.arg.centro8.curso.java.demo.entities.Reserva;
import or.arg.centro8.curso.java.demo.repositories.ReservaRepository;

public class ReservaController {
    private ReservaRepository rr=new ReservaRepository();
    private String mensaje="Aqui puedes visiaulizar y eliminar tus reservas";

    @GetMapping("reservas")
    public String getReserva(Model model,@RequestParam(name="buscarEstado",defaultValue = "")String buscarEstado,
                                          @RequestParam(name="buscarUsuario",defaultValue = "")Integer buscarUsuario){
          Reserva reserva=new Reserva();
          model.addAttribute("mensaje",mensaje);
          model.addAttribute("reservas",reserva);
          model.addAttribute("reservas",rr.getLikeEstadoReservas(buscarEstado));
          model.addAttribute("reservas",rr.getByIdUsuario(buscarUsuario));

          return "reservas";

    }
    @PostMapping("guardarReserva")
    public String guardarReserva(@ModelAttribute  Reserva reserva){
        rr.save(reserva);
        if(reserva.getId()>0)  mensaje="Se guardo tu reserva correctamente"+ reserva.getId();
        else                   mensaje="No se guardo tu reserva!";
        return"redirect:reservas";
    }
    @PostMapping("eliminarReserva")
    public String eliminarReserva(@RequestParam("id") int id){
        Reserva reserva=rr.getById(id);

        if(reserva.getId()>0)   {
            rr.remove(reserva);
            mensaje="Se elimino tu reserva ";
        }
        else{
            mensaje="No se encontro reserva con id! ";
        }
        return "redirect:reservas";
    }
}
