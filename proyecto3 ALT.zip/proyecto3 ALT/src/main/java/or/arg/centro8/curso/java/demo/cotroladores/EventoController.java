package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import or.arg.centro8.curso.java.demo.entities.Evento;
import or.arg.centro8.curso.java.demo.repositories.EventoRepository;

@Controller
public class EventoController {
   private  EventoRepository er=new EventoRepository();
   private String mensaje="Ingrese un evento";

@GetMapping("/evento")
   public String  getEvento(
 Model model,@RequestParam(name="buscar",defaultValue = "")String buscar){
   Evento evento= new Evento();
           model.addAttribute("mensaje",mensaje);
           model.addAttribute("evento",evento);
           model.addAttribute("busquedaPlaceholder","Buscar por el nombre");
           model.addAttribute("busquedaAction","evento");
           model.addAttribute("eventos",er.getLikeNombreEvento(buscar));
           return "evento";
 }
 @PostMapping("/guardarEvento")
 public String guardarEvento(@ModelAttribute Evento evento){
    er.save(evento);
    if(evento.getId()>0)    mensaje="Se Guardo el evento id"+ evento.getId();
        else                      mensaje="No se guardo el evento!";
        return "redirect:/evento";
 }


}
