package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Evento;

public class EventoRepository {
    private Connection conn=Connector.getConnection();
    public void save(Evento evento){
        if (evento==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into eventos(id_local,nombre_evento,descripcion,fecha,ciudad,ubicacion)values(?,?,?,?,?,?)",
                 PreparedStatement.RETURN_GENERATED_KEYS )){
            ps.setInt(1, evento.getId_local());
            ps.setString(2, evento.getNombre_evento());
            ps.setString(3, evento.getDescripcion());
            ps.setString(4, evento.getFecha());
            ps.setString(5, evento.getCiudad());
            ps.setString(6, evento.getUbicacion());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) evento.setId(rs.getInt(1));
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void remove(Evento evento){
        if(evento==null) return;
        try(PreparedStatement ps=conn.prepareStatement("delete from eventos where id=?")) {
            ps.setInt(1, evento.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public Evento getById(int id){
        return getAll()
                       .stream()
                       .filter(e->e.getId()==id)
                       .findAny()
                       .orElse(new Evento());               
    }
    public List<Evento> getAll(){
        List<Evento>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("Select * from Eventos")) {
            while(rs.next()){
                list.add(
                    new Evento(
                        rs.getInt("id"),
                        rs.getInt("id_local"),
                        rs.getString("nombre_evento"),
                        rs.getString("descripcion"),
                        rs.getString("fecha"),
                        rs.getString("ciudad"),
                        rs.getString("ubicacion")
                    )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Evento>getLikeCiudad(String ciudad){
        return getAll()
                       .stream()
                       .filter(e->e.getCiudad().toLowerCase().contains(ciudad.toLowerCase()))
                       .toList();
    }
    public List<Evento>getLikeNombreEvento(String nombre_evento){
        return getAll()
                       .stream()
                       .filter(e->e.getNombre_evento().toLowerCase().contains(nombre_evento.toLowerCase()))
                       .toList();
    }
}
