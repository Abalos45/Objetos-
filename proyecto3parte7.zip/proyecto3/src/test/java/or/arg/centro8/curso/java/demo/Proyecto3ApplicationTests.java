package or.arg.centro8.curso.java.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
