package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import or.arg.centro8.curso.java.demo.entities.Reserva;
import or.arg.centro8.curso.java.demo.repositories.ReservaRepository;

@Controller
public class ReservaController {
    private ReservaRepository rr=new ReservaRepository();
    private String mensaje="Aqui puedes visiaulizar y eliminar tus reservas";

    @GetMapping("/reserva")
    public String getReserva(Model model,@RequestParam(name="buscar",defaultValue = "")String buscar){
        Reserva reserva= new Reserva();
          model.addAttribute("mensaje",mensaje);
          model.addAttribute("reserva",reserva);
          model.addAttribute("reservas",rr.getLikeEstadoReservas(buscar));

          return "reserva";

    }
    @PostMapping("/guardarReserva")
    public String guardarReserva(@ModelAttribute  Reserva reserva){
        rr.save(reserva);
        if(reserva.getId()>0)  mensaje="Se guardo tu reserva correctamente"+ reserva.getId();
        else                   mensaje="No se guardo tu reserva!";
        return"redirect:/reserva";
    }
 
}
