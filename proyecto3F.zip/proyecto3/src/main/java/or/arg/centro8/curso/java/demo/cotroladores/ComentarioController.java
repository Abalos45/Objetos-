package or.arg.centro8.curso.java.demo.cotroladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import or.arg.centro8.curso.java.demo.entities.Comentario;
import or.arg.centro8.curso.java.demo.repositories.ComentarioRepository;
import or.arg.centro8.curso.java.demo.repositories.EventoRepository;

@Controller
public class ComentarioController {
    private ComentarioRepository cr=new ComentarioRepository();
    private EventoRepository  er= new EventoRepository();
    private String mensaje= "Ingresa tu comentario";


    @GetMapping("/comentario")
    public String getComentario(Model model,@RequestParam(name="buscar",defaultValue = "")String buscar){
        Comentario comentario=new Comentario();
        model.addAttribute("mensaje",mensaje);
        model.addAttribute("comentario",comentario);
        model.addAttribute("comentarios",cr.getLikeTextoComentario(buscar));
        return "comentario";

    }

    @PostMapping("guardarComentario")
    public String guardarCoemntario(@ModelAttribute  Comentario comentario){
        cr.save(comentario);
        if(comentario.getId()>0)  mensaje="Se guardo correctamente tu comentario"+ comentario.getId();
        else                      mensaje="No se guardo el comentario ";
        return "redirect:/comentario";

    }
}
