package or.arg.centro8.curso.java.demo.test;

import java.sql.Connection;
import java.sql.ResultSet;

import or.arg.centro8.curso.java.demo.connectors.Connector;

public class TestConnector {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select 'Conectado'");
            if(rs.next())       System.out.println(rs.getString(1));
            else                System.out.println("No Conectado");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No Conectado");
        }
    }
    
}
