package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Favoritos;
import or.arg.centro8.curso.java.demo.repositories.FavoritosRepository;

public class TestFavoritoRepository {
    public static void main(String[] args) {
        FavoritosRepository fr=new FavoritosRepository();

        Favoritos favoritos= new Favoritos(1, 02, 10, "2025-10-22");
        fr.save(favoritos);
        System.out.println(favoritos);

        fr.remove(fr.getById(3));

        System.out.println("-----------------------------------------------------------------------------------");

        fr.getAll().forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");
        fr.getByIdEventos(4).forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");
        fr.getByIdUsuario(5).forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------------");

        fr.getLikeFecha("2025-10-11").forEach(System.out::println);
    }
}
