package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Eventos;
import or.arg.centro8.curso.java.demo.repositories.EventosRepository;

public class TestEventosRepository {
    public static void main(String[] args) {
        EventosRepository er=new EventosRepository();
        Eventos eventos=new Eventos(0, 02, "Halloween", "Disfraz ganador", "01/11/2025","caba","Acoyte 3035");
        er.save(eventos);
        System.out.println(eventos);

       er.remove(er.getById(2));


        System.out.println("------------------------------------------");
        er.getAll().forEach(System.out::println);

        System.out.println("------------------------------------------");

        er.getLikeCiudad("Cartagena").forEach(System.out::println);

        System.out.println("------------------------------------------");
        er.getLikeNombreEvento("Carnaval del Caribe").forEach(System.out::println);

      

    }
}
