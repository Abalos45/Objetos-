package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Comentarios;

public class ComentariosRepository {
    private Connection conn=Connector.getConnection();
    public void save(Comentarios comentarios){
        if(comentarios==null)return;
        try(PreparedStatement ps=conn.prepareStatement(
            "insert into comentarios(id,id_usuario,id_evento,texto_comentario,fecha)values(?,?,?,?,?)",
                   PreparedStatement.RETURN_GENERATED_KEYS)){  
                    ps.setInt(1,comentarios.getId());
                    ps.setInt(2, comentarios.getId_usuario());
                    ps.setInt(3, comentarios.getId_evento());
                    ps.setString(4, comentarios.getTexto_comentario());
                    ps.setString(5, comentarios.getFecha());
                    ps.execute(); 
                    ResultSet rs=ps.getGeneratedKeys();
                    if(rs.next())comentarios.setId(rs.getInt(1));    
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void remove(Comentarios comentarios){
        if(comentarios==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from comentarios where id=?")) {
            ps.setInt(1, comentarios.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public Comentarios getById(int id){
        return getAll()
                       .stream()
                       .filter(c->c.getId()==id)
                       .findAny()
                       .orElse(new Comentarios());
    }
    public List<Comentarios> getAll(){
        List<Comentarios>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from comentarios")){
            while (rs.next()) {
                list.add(
                    new Comentarios(
                        rs.getInt("id"),
                        rs.getInt("id_usuario"),
                        rs.getInt("id_evento"),
                        rs.getString("texto_comentario"),
                        rs.getString("fecha")
                )
             );
                        
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
          return list;
    }
    public List<Comentarios>getByIdUsuario(int id_usuario){
        return getAll()
                       .stream()
                       .filter(c->c.getId_usuario()==id_usuario)
                       .toList();
                      

        
    }

    public List<Comentarios>getByIdEvento(int id_evento){
        return getAll()
                       .stream()
                       .filter(c->c.getId_evento()==id_evento)
                       .toList();
    }

    public List<Comentarios>getLikeFecha(String fecha ){
        return getAll()
                       .stream()
                       .filter(c->c.getFecha().contains(fecha))
                       .toList();
    }

    public List<Comentarios>getLikeTextoComentario(String texto_comentario){
        return getAll()
                       .stream()
                       .filter(c->c.getTexto_comentario().toLowerCase().contains(texto_comentario.toLowerCase()))
                       .toList();

    }


    
}
