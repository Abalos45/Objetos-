package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Favoritos;

public class FavoritosRepository {

    private Connection conn = Connector.getConnection();

    public void save(Favoritos favoritos) {
        if (favoritos == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into favoritos (id_usuario,id_eventos,fecha)values(?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, favoritos.getId_usuario());
            ps.setInt(2, favoritos.getId_eventos());
            ps.setString(3, favoritos.getFecha());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                favoritos.setId(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Favoritos favoritos) {
        if (favoritos == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from alumnos where id=?")) {
            ps.setInt(1, favoritos.getId());
            ps.execute();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Favoritos getById(int id) {
        return getAll()
                .stream()
                .filter(f -> f.getId() == id)
                .findAny()
                .orElse(new Favoritos());

    }
    public List<Favoritos>getAll() {
        List<Favoritos> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select *from favoritos")) {
            while (rs.next()) {
                list.add(
                        new Favoritos(
                                rs.getInt("id"),
                                rs.getInt("id_usuario"),
                                rs.getInt("id_eventos"),
                                rs.getString("fecha")));

            }

        } catch (Exception e) {
            System.out.println(e);
        }
                return list;
    }

    public List<Favoritos> getByIdUsuario(int id_usuario) {
        return getAll()
                        .stream()
                        .filter(f->f.getId_usuario()==id_usuario)
                        .toList();

    }

    public List<Favoritos> getByIdEventos(int id_eventos) {
        return getAll()
                       .stream()
                       .filter(f->f.getId_eventos()==id_eventos)
                       .toList();
    }
    public List<Favoritos>getLikeFecha(String fecha){
        return getAll()
                       .stream()
                       .filter(f->f.getFecha().contains(fecha))
                       .toList();

    }
}

