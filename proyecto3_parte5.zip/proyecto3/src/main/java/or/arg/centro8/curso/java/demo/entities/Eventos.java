package or.arg.centro8.curso.java.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Eventos {
    private int id;
    private int id_local;
    private String nombre_evento;
    private String descripcion;
    private String fecha;
    private String ciudad;
    private String ubicacion;

    
}
