package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Reservas;

public class ReservasRepository {
    private Connection conn= Connector.getConnection();

    public void save(Reservas reservas){
        if(reservas==null)return; 
        try (PreparedStatement ps=conn.prepareStatement(
            "Insert into reservas (id_usuario,id_evento,fecha_reservas,cantidad_personas,estado_reservas)values(?,?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
                ps.setInt(1,reservas.getId_usuario());
                ps.setInt(2, reservas.getId_evento());
                ps.setString(3, reservas.getFecha_reservas());
                ps.setInt(4, reservas.getCantidad_personas());
                ps.setString(5, reservas.getEstado_reservas());
                ps.execute();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()) reservas.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void remove(Reservas reservas){
        if(reservas==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from reservas where id=?")){
            ps.setInt(1,reservas.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public List<Reservas> getAll(){
        List<Reservas>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("select *from reservas")){
            while(rs.next()){
                list.add(
                    new Reservas(
                        rs.getInt("id"),
                        rs.getInt("id_usuario"),
                        rs.getInt("id_evento"),
                        rs.getString("fecha_reservas"),
                        rs.getInt("cantidad_personas"),
                        rs.getString("estado_reservas")
                    )
                );
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public Reservas getById(int id){
        return getAll()
                       .stream()
                       .filter(r->r.getId()==id)
                       .findAny()
                       .orElse(new Reservas());
    }

    public List<Reservas> getLikeEstadoReservas(String estado_reservas){
        return getAll()
                      .stream()
                      .filter(r->r.getEstado_reservas().toLowerCase().contains(estado_reservas))
                      .toList();

    }

    public List<Reservas>getByIdUsuario(int id_usuario){
        return getAll()
                       .stream()
                       .filter(r->r.getId_usuario()== id_usuario)
                       .toList();
                       
    }
}
