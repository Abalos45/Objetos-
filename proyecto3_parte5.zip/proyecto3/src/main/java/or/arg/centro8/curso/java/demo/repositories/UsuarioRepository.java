package or.arg.centro8.curso.java.demo.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import or.arg.centro8.curso.java.demo.connectors.Connector;
import or.arg.centro8.curso.java.demo.entities.Usuarios;

public class UsuarioRepository {

    private Connection conn=Connector.getConnection();

    public void save(Usuarios usuarios){
        if(usuarios==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into usuarios(nombre, apellido,edad,email,telefono,tipo_usuario,ciudad,zona)values(?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
                ps.setString(1,usuarios.getNombre());
                ps.setString(2, usuarios.getApellido());
                ps.setString(4,usuarios.getEmail());
                ps.setString(5,usuarios.getTelefono());
                ps.setString(5,usuarios.getTipo_usuario());
                ps.setString(6,usuarios.getCiudad());
                ps.setString(7,usuarios.getZona());
                ps.execute();
                ResultSet rs=ps.getGeneratedKeys();
                if(rs.next()) usuarios.setId(rs.getInt(1));

            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Usuarios usuarios){
        if(usuarios==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from usuarios ehere id=?")){
            ps.setInt(1,usuarios.getId());
            ps.execute();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Usuarios getById(int id){
        return getAll()
                       .stream()
                       .filter(u->u.getId()==id)
                       .findAny()
                       .orElse(new Usuarios());
    }
    public List<Usuarios> getAll(){
        List<Usuarios>list=new ArrayList<>();
        try  (ResultSet rs=conn.createStatement().executeQuery("select *from usuarios")) {
            while (rs.next()) {
                list.add(
                    new Usuarios(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("email"),
                        rs.getString("telefono"),
                        rs.getString("tipo_usuario"),
                        rs.getString("ciudad"),
                        rs.getString("zona")
                    )

                    
                );
                
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Usuarios>getLikeApellido(String apellido){
        return getAll()
                       .stream()
                       .filter(u->u.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                       .toList();
                    

    }
}
