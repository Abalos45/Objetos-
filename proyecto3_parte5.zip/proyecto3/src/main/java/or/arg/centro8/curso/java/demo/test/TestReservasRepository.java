package or.arg.centro8.curso.java.demo.test;

import or.arg.centro8.curso.java.demo.entities.Reservas;
import or.arg.centro8.curso.java.demo.repositories.ReservasRepository;

public class TestReservasRepository {
    
    public static void main(String[] args) {
        ReservasRepository rr=new ReservasRepository();

        Reservas reservas=new Reservas(1, 01, 01, "10/02/2025", 5, "confirmado");

        rr.save(reservas);
        System.out.println(reservas);

        rr.remove(rr.getById(2));

        System.out.println("-----------------------------------------");
        rr.getAll().forEach(System.out::println);

        System.out.println("-------------------------------------------------------");
        rr.getLikeEstadoReservas("confir").forEach(System.out::println);

        System.out.println("-------------------------------------------------------");

        rr.getByIdUsuario(3).forEach(System.out::println);


    }
}
