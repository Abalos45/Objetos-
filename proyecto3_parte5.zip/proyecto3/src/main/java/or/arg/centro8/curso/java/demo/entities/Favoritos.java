package or.arg.centro8.curso.java.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Favoritos {
    private int id;
    private int id_usuario;
    private int id_eventos;
    private String fecha;
}
