package test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.or.centro8.java.demo.entities.Auto;
import ar.or.centro8.java.demo.entities.Moto;
import ar.or.centro8.java.demo.entities.Vehiculo;

public class TestConsesionaria {
        public static void main(String[] args) {
                System.out.println("--Consesionaria--");

                List<Vehiculo> lista = new ArrayList<>();

                lista.add(new Auto("Peugeot", "206", 200000.0, 4));
                lista.add(new Moto("Honda", "Titan", 60000.00, "125c"));
                lista.add(new Auto("Peugeot", "208", 250000.00, 4));
                lista.add(new Moto("Yamaha", "YBR", 80500.50, "160c"));

                lista.stream().forEach(System.out::println);

                System.out.println("--------------------------------------------------------------");
                System.out.println("--------------------------------------------------------------");

                double precioMax = lista.stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                System.out.println("Vehículo más caro:");

                lista.stream()
                                .filter(v -> v.getPrecio() == precioMax)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

                System.out.println("--------------------------------------------------------------");

                double precioMin = lista.stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
                System.out.println("Vehículo más barato:");

                lista.stream()
                                .filter(v -> v.getPrecio() == precioMin)
                                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

                System.out.println("--------------------------------------------------------------");

                lista.stream()
                                .filter(vehiculo -> vehiculo.getModelo()
                                                .toLowerCase().contains("y"))
                                .forEach(v -> System.out.println("Vehiculo que contiene en el modelo la letra 'Y': "
                                                + v.getMarca() + " " + v.getModelo() + " $"
                                                + Vehiculo.df.format(v.getPrecio())));

                System.out.println("--------------------------------------------------------------");
                System.out.println("--------------------------------------------------------------");

                System.out.println("Vehiculos ordenados por precio de mayor a menor");

                lista.stream()
                              .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                              .forEach(v->System.out.println(v.getMarca()+" "+ v.getModelo()));


                System.out.println("--------------------------------------------------------------");
                System.out.println("--------------------------------------------------------------");

                System.out.println("Vehiculos ordenados por orden natural");

                lista.stream().sorted().forEach(System.out::println);

        }

}
