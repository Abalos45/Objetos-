package ar.or.centro8.java.demo.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public static final DecimalFormat df = new DecimalFormat("#,###.00");

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public String getPrecioFormateado(){
        return df.format(precio);
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Vehiculo marca=" + marca + " // modelo=" + modelo + " // precio=  $" + getPrecioFormateado();
    }

    @Override
    public int compareTo(Vehiculo para) {
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String paraVehiculo = para.getMarca() + "," + para.getModelo() + "," + para.getPrecio();

        return thisVehiculo.compareTo(paraVehiculo);
    }

}
